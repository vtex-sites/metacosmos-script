bnb.scene.enableRecognizerFeature(bnb.FeatureID.FRX);
bnb.scene.enableRecognizerFeature(bnb.FeatureID.LIGHT_CORRECTION);
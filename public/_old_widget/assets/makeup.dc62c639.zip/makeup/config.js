'use strict';

const loraza = require('./loraza.js');

Object.assign(globalThis, loraza.m);
/* Feel free to add your custom code below */

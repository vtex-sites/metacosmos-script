'use strict';

require('bnb_js/global');
require('./modules/scene/index.js');
const modules_eyes_index = require('./modules/eyes/index.js');
const modules_index = require('./modules/index.js');

bnb.log(`\n\nMakeup API version: ${"1.4.0-a1bb35ba9c9253584ee075939e64f6569523e8b9"}\n`);
const Eyes = new modules_eyes_index.Eyes();
const setState = modules_index.createSetState({
    Eyes,
});

const m = /*#__PURE__*/Object.freeze({
    __proto__: null,
    Eyes: Eyes,
    setState: setState
});

exports.m = m;

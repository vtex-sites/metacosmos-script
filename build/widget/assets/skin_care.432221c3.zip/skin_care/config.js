const am = bnb.scene.getAssetManager()

const Acne_image = am.findImage("Acne").asTexture()
const Pores_image = am.findImage("Pores").asTexture()
const Wrinkles_image = am.findImage("Wrinkles").asTexture()
const Texture_image = am.findImage("Texture").asTexture()
const Rosacea_image = am.findImage("Rosacea").asTexture()

let ID = 0;

const images = {
    "acne": Acne_image,
    "pores": Pores_image,
    "wrinkles": Wrinkles_image,
    "idle": Texture_image,
    "rosacea": Rosacea_image
}

const acnes = [
    "images/acne_texture_5.png",
    "images/acne_texture_2.png",
    "images/acne_texture_6.png",
    "images/acne_texture_7.png",
    "images/acne_texture_1.png",
    "images/acne_texture_0.png",
    "images/acne_texture_9.png",
    "images/acne_texture_3.png",
    "images/acne_texture_4.png",
    "images/acne_texture_8.png",
]

const pores = [
    "images/pores_texture_3.png",
    "images/pores_texture_1.png",
    "images/pores_texture_0.png",
    "images/pores_texture_4.png",
    "images/pores_texture_8.png",
    "images/pores_texture_2.png",
    "images/pores_texture_7.png",
    "images/pores_texture_6.png",
    "images/pores_texture_9.png",
    "images/pores_texture_5.png",
]
const wrinkles = [
    "images/wrinkles_texture_7.png",
    "images/wrinkles_texture_2.png",
    "images/wrinkles_texture_3.png",
    "images/wrinkles_texture_8.png",
    "images/wrinkles_texture_1.png",
    "images/wrinkles_texture_0.png",
    "images/wrinkles_texture_9.png",
    "images/wrinkles_texture_5.png",
    "images/wrinkles_texture_4.png",
    "images/wrinkles_texture_6.png",
]
const rosacea = [
    "images/rosacea_texture_5.png",
    "images/rosacea_texture_7.png",
    "images/rosacea_texture_2.png",
    "images/rosacea_texture_4.png",
    "images/rosacea_texture_8.png",
    "images/rosacea_texture_3.png",
    "images/rosacea_texture_6.png",
    "images/rosacea_texture_1.png",
    "images/rosacea_texture_0.png",
    "images/rosacea_texture_9.png",
]

let paths = {
    "acne0": "images/acne_texture_5.png",
    "acne1": "images/acne_texture_2.png",
    "acne2": "images/acne_texture_6.png",
    "acne3": "images/acne_texture_7.png",
    "acne4": "images/acne_texture_1.png",
    "acne5": "images/acne_texture_0.png",
    "acne6": "images/acne_texture_9.png",
    "acne7": "images/acne_texture_3.png",
    "acne8": "images/acne_texture_4.png",
    "acne9": "images/acne_texture_8.png",
    "pores0": "images/pores_texture_3.png",
    "pores1": "images/pores_texture_1.png",
    "pores2": "images/pores_texture_0.png",
    "pores3": "images/pores_texture_4.png",
    "pores4": "images/pores_texture_8.png",
    "pores5": "images/pores_texture_2.png",
    "pores6": "images/pores_texture_7.png",
    "pores7": "images/pores_texture_6.png",
    "pores8": "images/pores_texture_9.png",
    "pores9": "images/pores_texture_5.png",
    "wrinkles0": "images/wrinkles_texture_7.png",
    "wrinkles1": "images/wrinkles_texture_2.png",
    "wrinkles2": "images/wrinkles_texture_3.png",
    "wrinkles3": "images/wrinkles_texture_8.png",
    "wrinkles4": "images/wrinkles_texture_1.png",
    "wrinkles5": "images/wrinkles_texture_0.png",
    "wrinkles6": "images/wrinkles_texture_9.png",
    "wrinkles7": "images/wrinkles_texture_5.png",
    "wrinkles8": "images/wrinkles_texture_4.png",
    "wrinkles9": "images/wrinkles_texture_6.png",
    "rosacea0": "images/rosacea_texture_5.png",
    "rosacea1": "images/rosacea_texture_7.png",
    "rosacea2": "images/rosacea_texture_2.png",
    "rosacea3": "images/rosacea_texture_4.png",
    "rosacea4": "images/rosacea_texture_8.png",
    "rosacea5": "images/rosacea_texture_3.png",
    "rosacea6": "images/rosacea_texture_6.png",
    "rosacea7": "images/rosacea_texture_1.png",
    "rosacea8":  "images/rosacea_texture_0.png",
    "rosacea9":  "images/rosacea_texture_9.png",
    "idle": "images/idle_texture.png",
    "null": "images/null_image.png"
}

function setActive(id, ...region){
    ID = id;
    region.forEach(el => {
        if(Object.keys(images).includes(el.toLowerCase())){
            if(el.toLowerCase() == "idle"){
                images["idle"].load(paths["idle"]);
            }else[
                images[el.toLowerCase()].load(paths[el.toLowerCase()+ID])

            ]

        }
        })
}

function setClear(...region){
    region.forEach(el => {
        if(Object.keys(images).includes(el.toLowerCase()))
            images[el.toLowerCase()].load(paths["null"])
    })
}

function clearAll(){
    for (const value of Object.values(images)) {
        value.load(paths["null"])
      }
}